/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Workstation
 */
public class DateTime {
    private String erc;
    private String time_in;
    private String time_out;
    private String date;
    DateTime(String erc,String time_in,String time_out,String date){
    this.erc=erc;
    this.time_in=time_in;
    this.time_out=time_out;
    this.date=date;
    }
public String geterc(){
return erc;
}
public void seterc(String erc){
this.erc=erc;
}
public String gettime_in(){
return time_in;
}
public void settime_in(String time_in){
this.time_in=time_in;
}
public String gettime_out(){
return time_out;
}
public void settime_out(String time_out){
this.time_out=time_out;
}
public String getdate(){
return date;
}
public void setdate(String date){
this.date=date;
}    
    
}
