/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Workstation
 */
public class Profiles {
    private int ID;
    private String fname;
    private String mname;
    private String lname;
    private String dept;
    private String gender;
    private String erc;

    Profiles(int ID, String fname, String mname, String lname, String dept, 
            String gender, String ern){
        this.ID=ID;
        this.fname=fname;
        this.mname=mname;
        this.lname=lname;
        this.dept=dept;
        this.gender=gender;
        this.erc=erc;
    }
    public int getID(){
    return ID;
    }
    public void setID(int ID){
    this.ID=ID;
    }
    public String getfname(){
    return fname;
    }
    public void setfname(String fname){
    this.fname=fname;
    }
    public String getmname(){
    return fname;
    }
    public void setmname(String mname){
    this.mname=mname;
    }
    public String getlname(){
    return lname;
    }
    public void setlname(String lname){
    this.lname=lname;
    }
    public String getdept(){
    return dept;
    }
    public void setdept(String dept){
    this.dept=dept;
    }
    public String getgender(){
    return gender;
    }
    public void setgender(String gender){
    this.gender=gender;
    }
    public String geterc(){
    return erc;
    }
    public void setern(String ern){
    this.erc=erc;
    }
}
