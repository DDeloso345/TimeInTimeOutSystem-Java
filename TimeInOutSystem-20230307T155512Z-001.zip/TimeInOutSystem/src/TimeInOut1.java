import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.sql.*;
public class TimeInOut1 extends javax.swing.JFrame {
    String erctio;
    String pvptio;
    Details tc = new Details();
    public TimeInOut1() {
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        timein = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        erc = new javax.swing.JTextField();
        clear = new javax.swing.JButton();
        exit = new javax.swing.JButton();
        timeout = new javax.swing.JButton();
        admin = new javax.swing.JButton();
        emlist = new javax.swing.JButton();
        pvp = new javax.swing.JPasswordField();
        emlog = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        timein.setText("Time In");
        timein.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeinActionPerformed(evt);
            }
        });
        timein.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                timeinKeyPressed(evt);
            }
        });

        jLabel1.setText("Time In/Time Out System");

        jLabel2.setText("Please fill in the provided fields:");

        jLabel3.setText("Employee Reference Code:");

        jLabel4.setText("Personal Verification Passcode:");

        clear.setText("Clear");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });
        clear.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                clearKeyPressed(evt);
            }
        });

        exit.setText("Exit");
        exit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitActionPerformed(evt);
            }
        });
        exit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                exitKeyPressed(evt);
            }
        });

        timeout.setText("Time Out");
        timeout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                timeoutActionPerformed(evt);
            }
        });
        timeout.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                timeoutKeyPressed(evt);
            }
        });

        admin.setText("Perform Adminstrative Actions (Requires Administrator Credentials)");
        admin.setToolTipText("");
        admin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminActionPerformed(evt);
            }
        });
        admin.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                adminKeyPressed(evt);
            }
        });

        emlist.setText("Show List of Employees");
        emlist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emlistActionPerformed(evt);
            }
        });
        emlist.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                emlistKeyPressed(evt);
            }
        });

        emlog.setText("Show Employee Log");
        emlog.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emlogActionPerformed(evt);
            }
        });
        emlog.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                emlogKeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(pvp)
                                    .addComponent(erc, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(emlog)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(emlist))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(timein)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(timeout)
                                        .addGap(30, 30, 30)
                                        .addComponent(clear)
                                        .addGap(18, 18, 18)
                                        .addComponent(exit)))))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(admin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(149, 149, 149))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(136, 136, 136))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(erc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(pvp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(timein)
                    .addComponent(timeout)
                    .addComponent(clear)
                    .addComponent(exit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emlog)
                    .addComponent(emlist))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(admin)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void timeinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeinActionPerformed

      tc.setERCTimeInOut(erc.getText());
      tc.setPVPTimeInOut(pvp.getText());
        if(erc.getText().length()> 0&&pvp.getText().length()>0){
        try{
        erctio = tc.getERCTimeInOut();
        pvptio = tc.getPVPTimeInOut();
        DBCon dbc = new DBCon();
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/system","root","");
        PreparedStatement pst = con.prepareStatement("Select *from em_list where erc=? and pvp=?");
        pst.setString(1, erctio);
        pst.setString(2, pvptio);
        ResultSet rs = pst.executeQuery();
        if(rs.next()){
        JOptionPane.showMessageDialog(null, "The credentials you have entered has been recognized by the system.");
        dbc.QueryUpdate("Insert into timeinout (erc,time_in,date) values ('"+erc.getText()+"',curtime(),curdate())");
        JOptionPane.showMessageDialog(null,"You have successfully timed in!");
        }
        else{
          JOptionPane.showMessageDialog(null, "The credentials that you have entered was not recognized by the system.\nTry again.","Error!",JOptionPane.ERROR_MESSAGE);      
                }     
 }
 catch(Exception e){
     JOptionPane.showMessageDialog(null,"The program cannot proceed in doing the intended action and the error may have"
          + "\nbeen caused by one of the following reasons:"
          + "\n1. A connection between the program and the database cannot be clearly established."
          + "\n2. Your XAMPP Control Panel has not been opened. "
          + "\n3. You haven't turned on the 'Apache' and 'MySQL' options in your XAMPP Control Panel."
          + "\n4. A suitable JDBC driver was not found while performing the said action."
          + "\nFor more information regarding on the error, please refer to the following statement below:"
          + "\n"+e,"Error!",JOptionPane.ERROR_MESSAGE);
 }
        }
        else{
        JOptionPane.showMessageDialog(null, "You have not entered any credentials."
        + "\nPlease enter a valid one to have your time in/time out logged.");
        }
    }//GEN-LAST:event_timeinActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        pvp.setText("");
        erc.setText("");
    }//GEN-LAST:event_clearActionPerformed

    private void exitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitActionPerformed
try{
        TimeInOut1 tio = new TimeInOut1();
        String i1 = JOptionPane.showInputDialog(this, "Do you want to continue in using the system?\n Press [1] to return to the program.\n Press [2] to close the program.","Note:",JOptionPane.INFORMATION_MESSAGE);     
        if(i1.equals("1")){
   
    tio.setVisible(true);
    dispose();
    }
        else if(i1.equals("2")){
        System.exit(0);
        }
        else {
        JOptionPane.showMessageDialog(this, "Please enter characters that are provided in the choices.","Error", JOptionPane.ERROR_MESSAGE);
        tio.exitActionPerformed(evt);
        }
}
catch(NullPointerException e){}
    }//GEN-LAST:event_exitActionPerformed

    private void timeoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_timeoutActionPerformed
      Details tc = new Details();
      tc.setERCTimeInOut(erc.getText());
      tc.setPVPTimeInOut(pvp.getText());
if(erc.getText().length()>0&&pvp.getText().length()>0){        
     try{
        erctio = tc.getERCTimeInOut();
        pvptio = tc.getPVPTimeInOut();
        DBCon dbc = new DBCon();
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/system","root","");
        PreparedStatement pst = con.prepareStatement("Select *from em_list where erc=? and pvp=?");
        pst.setString(1, erctio);
        pst.setString(2, pvptio);
        ResultSet rs = pst.executeQuery();
        
        if(rs.next()){
            JOptionPane.showMessageDialog(null, "The credentials you have entered has been recognized by the system.");
             dbc.QueryUpdate("Insert into timeinout (erc,time_out,date) values ('"+erc.getText()+"',curtime(),curdate())");
        JOptionPane.showMessageDialog(null,"You have successfully timed out!");
        }
        else{
          JOptionPane.showMessageDialog(null, "The credentials that you have entered was not recognized by the system.\nTry again.","Error!",JOptionPane.ERROR_MESSAGE);      
                }
 }
 catch(Exception e){
  JOptionPane.showMessageDialog(null,"The program cannot proceed in doing the intended action and the error may have"
          + "\nbeen caused by one of the following reasons:"
          + "\n1. A connection between the program and the database cannot be clearly established."
          + "\n2. Your XAMPP Control Panel has not been opened. "
          + "\n3. You haven't turned on the 'Apache' and 'MySQL' options in your XAMPP Control Panel."
          + "\n4. A suitable JDBC driver was not found while performing the said action."
          + "\nFor more information regarding on the error, please refer to the following statement below:"
          + "\n"+e,"Error!",JOptionPane.ERROR_MESSAGE);
 }
}
else{
JOptionPane.showMessageDialog(null, "You have not entered any credentials."
        + "\nPlease enter a valid one to have your time in/time out logged.");
}
    }//GEN-LAST:event_timeoutActionPerformed

    private void adminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminActionPerformed
       dispose();
       AdLog al = new AdLog();
       al.setVisible(true);
    }//GEN-LAST:event_adminActionPerformed

    private void emlistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emlistActionPerformed
       dispose();
       EmList el = new EmList();
       el.setVisible(true);
    }//GEN-LAST:event_emlistActionPerformed

    private void emlogActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emlogActionPerformed
    dispose();
       EmLog el = new EmLog();
       el.setVisible(true);
    }//GEN-LAST:event_emlogActionPerformed

    private void adminKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_adminKeyPressed

    }//GEN-LAST:event_adminKeyPressed

    private void emlogKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emlogKeyPressed

    }//GEN-LAST:event_emlogKeyPressed

    private void emlistKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_emlistKeyPressed

    }//GEN-LAST:event_emlistKeyPressed

    private void timeinKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_timeinKeyPressed

    }//GEN-LAST:event_timeinKeyPressed

    private void timeoutKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_timeoutKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_timeoutKeyPressed

    private void clearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_clearKeyPressed
  
    }//GEN-LAST:event_clearKeyPressed

    private void exitKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_exitKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_exitKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TimeInOut1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TimeInOut1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TimeInOut1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TimeInOut1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TimeInOut1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton admin;
    private javax.swing.JButton clear;
    private javax.swing.JButton emlist;
    private javax.swing.JButton emlog;
    private javax.swing.JTextField erc;
    private javax.swing.JButton exit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPasswordField pvp;
    private javax.swing.JButton timein;
    private javax.swing.JButton timeout;
    // End of variables declaration//GEN-END:variables

    private void getString(String time_in) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
