import java.sql.*;
import javax.swing.JOptionPane;

public class DBCon{
    Connection con;
    public DBCon() throws Exception{
    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/system","root","");
    }
public void QueryUpdate(String Query){
try{
Statement st = con.createStatement();
st.executeUpdate(Query);
}
catch(Exception e){
JOptionPane.showMessageDialog(null, e);
}
}
 
}