import java.awt.event.KeyEvent;
import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.table.TableModel;
import net.proteanit.sql.DbUtils;
public class IUDInterface extends javax.swing.JFrame {
    String ID;
    String fn;
    String mi;
    String ln;
    String dep;
    String gend;
    String ERC;
    String PVP;
    Details tc = new Details();
    public IUDInterface() {
        initComponents();
        Display();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        fname = new javax.swing.JTextField();
        erc = new javax.swing.JTextField();
        dept = new javax.swing.JComboBox<>();
        gen = new javax.swing.JComboBox<>();
        ins = new javax.swing.JButton();
        upd = new javax.swing.JButton();
        del = new javax.swing.JButton();
        clear = new javax.swing.JButton();
        clear1 = new javax.swing.JButton();
        refresh = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        pvp = new javax.swing.JTextField();
        mname = new javax.swing.JTextField();
        lname = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        displayad = new javax.swing.JTable();
        id = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Profile Modifier Interface");

        jLabel2.setText("First Name:");

        jLabel3.setText("Middle Initial:");

        jLabel4.setText("Last Name:");

        jLabel5.setText("Department:");

        jLabel6.setText("Gender:");

        jLabel7.setText("Employee's Reference Code (ERC):");

        jLabel8.setText("Personal Verification Passcode (PVP):");

        fname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                fnameFocusLost(evt);
            }
        });
        fname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                fnameKeyPressed(evt);
            }
        });

        dept.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrative", "Sales & Marketing", "Logistics", "Maintainance" }));

        gen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female" }));

        ins.setText("Insert");
        ins.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insActionPerformed(evt);
            }
        });

        upd.setText("Update");
        upd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updActionPerformed(evt);
            }
        });

        del.setText("Delete");
        del.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delActionPerformed(evt);
            }
        });

        clear.setText("Clear All Fields");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        clear1.setText("Exit Interface");
        clear1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear1ActionPerformed(evt);
            }
        });

        refresh.setText("Refresh Table");
        refresh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshActionPerformed(evt);
            }
        });

        jLabel9.setText("ReadMe:");

        jButton1.setText("?");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel10.setText("ID:");

        mname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                mnameFocusLost(evt);
            }
        });
        mname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                mnameKeyPressed(evt);
            }
        });

        lname.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                lnameFocusLost(evt);
            }
        });
        lname.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                lnameKeyPressed(evt);
            }
        });

        displayad.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "First Name", "Middle Initial", "Last Name", "Department", "Gender", "ERC", "PVP"
            }
        ));
        displayad.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                displayadMouseClicked(evt);
            }
        });
        displayad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                displayadKeyPressed(evt);
            }
        });
        jScrollPane1.setViewportView(displayad);

        id.setForeground(new java.awt.Color(100, 100, 100));

        jLabel11.setText("Employee List");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel8, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(erc, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
                                .addComponent(fname)
                                .addComponent(dept, 0, 249, Short.MAX_VALUE)
                                .addComponent(gen, 0, 249, Short.MAX_VALUE)
                                .addComponent(pvp, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
                                .addComponent(mname, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
                                .addComponent(lname, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE))
                            .addComponent(id, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(refresh)
                                .addGap(18, 18, 18)
                                .addComponent(clear1))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(ins)
                                .addGap(18, 18, 18)
                                .addComponent(upd)
                                .addGap(18, 18, 18)
                                .addComponent(del)
                                .addGap(18, 18, 18)
                                .addComponent(clear)))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 736, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(id, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 22, Short.MAX_VALUE))
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(fname, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(mname, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lname, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dept, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(gen, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(erc, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pvp, javax.swing.GroupLayout.DEFAULT_SIZE, 26, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ins)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(upd)
                                .addComponent(del)
                                .addComponent(clear)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(refresh)
                                .addComponent(clear1))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jButton1)
                                .addComponent(jLabel9))))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
 public void capitalize(){
   if(fname.getText().length()>0){  
    String fn  =fname.getText();
    fn=fn.substring(0,1).toUpperCase() + fn.substring(1).toLowerCase();
    fname.setText(fn);
   }
   if(mname.getText().length()>0){
    String mn= mname.getText();
    mn=mn.substring(0,1).toUpperCase() + mn.substring(1).toLowerCase();
    mname.setText(mn);
    }
   if(lname.getText().length()>0){
    String ln=lname.getText();
    ln=ln.substring(0,1).toUpperCase() + ln.substring(1).toLowerCase();
    lname.setText(ln);
    }
    }
    private void fnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_fnameKeyPressed
    capitalize();
    }//GEN-LAST:event_fnameKeyPressed

    private void fnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_fnameFocusLost
     capitalize();
    }//GEN-LAST:event_fnameFocusLost

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        JOptionPane.showMessageDialog(null, "1.) When using the 'Update' or 'Delete' feature, select first the following row that you wish to modify."
            + "\n2.) The same rules are to be followed in the 'Update' feature when using the 'Delete' feature with slight modifications."
            + "\nIf a row is selected from the table without any valid numerical value from the ID column then pressing the 'Delete' button, an error notification will be"
            + "\nsent to the user reminding him to select a row in the ID column that will have a valid numerical value."
            + "\nto restore the previous details before deleting the selected profile."
            + "\n3.) To transport the selected row directly to the text fields, the user must click the selected profile to perform the said action.");
    }//GEN-LAST:event_jButton1ActionPerformed

    private void refreshActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshActionPerformed
        try{
            Connection con = con=DriverManager.getConnection("jdbc:mysql://localhost:3306/system","root","");
            String sql = "Select *from em_list";
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            displayad.setModel(DbUtils.resultSetToTableModel(rs));
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"An error has been detected leading to the said action unable to be performed and may have been caused by the following reason."
                    + "\n1.) A stable connection between the program and the database could not be established. Please open your XAMPP Control Panel and start"
                    + "\nthe 'Apache' and 'MySQL' services."
                    + "\nFor more information regarding on the problem, please refer to the statement below:\n"+e,"Error!",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_refreshActionPerformed

    private void clear1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear1ActionPerformed
        dispose();
        TimeInOut1 tio = new TimeInOut1();
        tio.setVisible(true);
    }//GEN-LAST:event_clear1ActionPerformed

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        fname.setText("");
        mname.setText("");
        lname.setText("");
        erc.setText("");
        pvp.setText("");
    }//GEN-LAST:event_clearActionPerformed

    private void delActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delActionPerformed
   tc.setid(id.getText());
        try{
        String s  = JOptionPane.showInputDialog(null, "Are you sure you wan to delete the selected profile?"
                + "\nPress [1] to continue.\nPress [2] to return to the interface.","Message",JOptionPane.WARNING_MESSAGE);
            if(s.equals("1")){
                try{
               ID=tc.getid();
               DBCon dbc = new DBCon();
               dbc.QueryUpdate("delete from em_list where id="+ID);
               JOptionPane.showMessageDialog(null,"The action 'Delete' was successfully performed."
                       + "\nPlease refresh the table to see the changes.");
                }
                catch(Exception e){
                JOptionPane.showMessageDialog(null,"An error has been detected."
                        + "\nPlease see the if the ID number is valid or not null."
                        + "\nFor more information, please refer on the statement below."
                        + "\n"+e,"Error!",JOptionPane.ERROR_MESSAGE);
                }
                 }
            else if(s.equals("2")){
                IUDInterface iud = new IUDInterface();
                dispose();
                iud.setVisible(true);
        }
            else{
                JOptionPane.showMessageDialog(null,"Please enter characters specified from the choices.");
            }
        }
        catch(NullPointerException e){
                    }
    }//GEN-LAST:event_delActionPerformed

    private void updActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updActionPerformed
       tc.setid(id.getText());
       tc.setfname(fname.getText());
       tc.setmname(mname.getText());
       tc.setlname(lname.getText());
       tc.setdept(dept.getSelectedItem().toString());
       tc.setgender(gen.getSelectedItem().toString());
       tc.setERC(erc.getText());
       tc.setPVP(pvp.getText());
        try{
           ID=tc.getid();
           fn=tc.getfname();
           mi=tc.getmname();
           ln=tc.getlname();
           dep=tc.getdept();
           gend=tc.getgender();
           ERC=tc.getERC();
           PVP=tc.getPVP();
            DBCon dbc = new DBCon();
            dbc.QueryUpdate("update em_list set first_name='"+fn+"',middle_initial='"+mi+"',last_name='"+ln
                +"',department='"+dep+"',gender='"+gend+"',erc='"+ERC+"',pvp='"+PVP
                +"' where id="+ID);
            JOptionPane.showMessageDialog(null,"Data has been successfully updated.\nPlease refresh the table to see the changes\nof the updated profile.");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"An error has been detected leading to the said action unable to be performed and may have been caused by the following reason."
                    + "\n1.) A stable connection between the program and the database could not be established."
                    + "\nPlease open your XAMPP Control Panel and startthe 'Apache' and 'MySQL' services."
                    + "\nFor more information regarding on the problem, please"
                    + "\nrefer to the statement below:\n"+e,"Error!",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_updActionPerformed

    private void insActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insActionPerformed
       tc.setfname(fname.getText());
       tc.setmname(mname.getText());
       tc.setlname(lname.getText());
       tc.setdept(dept.getSelectedItem().toString());
       tc.setgender(gen.getSelectedItem().toString());
       tc.setERC(erc.getText());
       tc.setPVP(pvp.getText());
        if(fname.getText().length()>0&&mname.getText().length()>0&&lname.getText().length()>0&&erc.getText().length()>0&&pvp.getText().length()>0){ 
       try{
           fn=tc.getfname();
           mi=tc.getmname();
           ln=tc.getlname();
           dep=tc.getdept();
           gend=tc.getgender();
           ERC=tc.getERC();
           PVP=tc.getPVP();
            DBCon dbc = new DBCon();
            dbc.QueryUpdate("Insert into em_list (first_name,middle_initial,last_name,department,gender,erc,pvp) values ('"
                    +fn+"','"+mi+"','"+ln+"','"+dep
                    +"','"+gend+"','"+ERC+"','"+PVP+"')");
            JOptionPane.showMessageDialog(this, "A new profile has been added."
                    + "\nPlease refresh the table to check"
                    + "\nsee the updated list of profiles.");
       }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,"An error has been detected leading to the said action unable to be performed and may have been caused by the following reason."
                    + "\n1.) A stable connection between the program and the database could not be established. Please open your XAMPP Control Panel and start"
                    + "\nthe 'Apache' and 'MySQL' services."
                    + "\nFor more information regarding on the problem, please refer to the statement below:\n"+e,"Error!",JOptionPane.ERROR_MESSAGE);
        }
       }
    else if(fname.getText().equals("")||mname.getText().equals("")||lname.getText().equals("")||erc.getText().equals("")||pvp.getText().equals("")){
            JOptionPane.showMessageDialog(null,"One of the fields has not been filled.","Error!",JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_insActionPerformed

    private void mnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_mnameKeyPressed
       capitalize();
    }//GEN-LAST:event_mnameKeyPressed

    private void mnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_mnameFocusLost
       capitalize();
    }//GEN-LAST:event_mnameFocusLost

    private void lnameKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_lnameKeyPressed
        capitalize();
    }//GEN-LAST:event_lnameKeyPressed

    private void lnameFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_lnameFocusLost
     capitalize();
    }//GEN-LAST:event_lnameFocusLost

    private void displayadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_displayadKeyPressed
        int k=evt.getKeyCode();
        if(k==KeyEvent.VK_UP||k==KeyEvent.VK_DOWN||k==KeyEvent.VK_LEFT||k==KeyEvent.VK_RIGHT){
            displayad.grabFocus();
        }
        else if(k!=KeyEvent.VK_UP||k!=KeyEvent.VK_DOWN||k!=KeyEvent.VK_LEFT||k!=KeyEvent.VK_RIGHT){
            boolean b = displayad.isEditing();
            if(b==false){
                JOptionPane.showMessageDialog(null, "Fields in this table cannot be edited\nand are for display/reference purposes only."
                    + "\nIf you want to edit, type the values that you\nwish to insert in the provided text fields.");
            }
        }
    }//GEN-LAST:event_displayadKeyPressed

    private void displayadMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_displayadMouseClicked
        try{
        boolean b = displayad.isEditing();
        if(b==false){
            JOptionPane.showMessageDialog(null, "Fields in this table cannot be edited\nand are for display/reference purposes only."
                    + "\nIf you want to edit, type the values that you\nwish to insert in the provided text fields.");
        }
        int i=displayad.getSelectedRow();
        TableModel model= displayad.getModel();
        id.setText(model.getValueAt(i, 0).toString());
        fname.setText(model.getValueAt(i, 1).toString());
        mname.setText(model.getValueAt(i, 2).toString());
        lname.setText(model.getValueAt(i, 3).toString());
        dept.setSelectedItem(model.getValueAt(i, 4).toString());
        gen.setSelectedItem(model.getValueAt(i, 5).toString());
        erc.setText(model.getValueAt(i, 6).toString());
        pvp.setText(model.getValueAt(i, 7).toString());
        }
        catch(NullPointerException e){
        }
    }//GEN-LAST:event_displayadMouseClicked
public void Display(){ 
try{
Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/system","root","");
String sql = "Select *from em_list";
PreparedStatement pst = con.prepareStatement(sql);
ResultSet rs = pst.executeQuery();
displayad.setModel(DbUtils.resultSetToTableModel(rs));
}
catch(Exception e){
JOptionPane.showMessageDialog(null,"The program has failed to connect to the database for the following reasons:"
        + "\n1.) Your XAMPP Control Panel has not yet been opened."
        + "\n2.) You may have opened your XAMPP Control Panel, but have not yet started "
        + "\nthe 'Apache' and 'MySQL' services."
        + "\nAs a result, you cannot avail the 'Insert','Update','Refresh Table' & 'Delete' features."
        + "\nThe table will also not display the employee list and their details"
        + "\nunless a fix has been applied to the current problem. Only the 'Clear All Fields'"
        + "\n'Exit Interface' & the '?' will still function as normal under the current circumstances."
        + "\nFor more information regarding the problem, refer to the statement below:"
        +"\n"+e,"Error!",JOptionPane.ERROR_MESSAGE);
}
}
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(IUDInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(IUDInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(IUDInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(IUDInterface.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new IUDInterface().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton clear;
    private javax.swing.JButton clear1;
    private javax.swing.JButton del;
    private javax.swing.JComboBox<String> dept;
    private javax.swing.JTable displayad;
    private javax.swing.JTextField erc;
    private javax.swing.JTextField fname;
    private javax.swing.JComboBox<String> gen;
    private javax.swing.JLabel id;
    private javax.swing.JButton ins;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lname;
    private javax.swing.JTextField mname;
    private javax.swing.JTextField pvp;
    private javax.swing.JButton refresh;
    private javax.swing.JButton upd;
    // End of variables declaration//GEN-END:variables
}
