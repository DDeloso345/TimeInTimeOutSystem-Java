public class Details {
    private String erc;
    private String pvp;
    private String aduser;
    private String adpass;
    private String id;
    private String fname;
    private String mname;
    private String lname;
    private String dept;
    private String gender;
    private String ERC;
    private String PVP;

 public void setERCTimeInOut(String erc){
 this.erc=erc;
 }
 public String getERCTimeInOut(){
 return erc;
 }
 public void setPVPTimeInOut(String pvp){
 this.pvp=pvp;
 }
 public String getPVPTimeInOut(){
 return pvp;
 }
 public void setAdUser(String aduser){
 this.aduser=aduser;
 }
 public String getAdUser(){
 return aduser;
 }
 public void setAdPass(String adpass){
 this.adpass=adpass;
 }
 public String getAdPass(){
 return adpass;
 }
 public void setid(String id){
 this.id=id;
 }
 public String getid(){
 return id;
 }
 public void setfname(String fname){
 this.fname=fname;
 }
 public String getfname(){
 return fname;
 }
 public void setmname(String mname){
 this.mname=mname;
 }
 public String getmname(){
 return fname;
 }
 public void setlname(String lname){
 this.lname=lname;
 }
 public String getlname(){
 return lname;
 }
 public void setdept(String dept){
 this.dept=dept;
 }
 public String getdept(){
 return dept;
 }
 public void setgender(String gender){
 this.gender=gender;
 }
 public String getgender(){
 return gender;
 }
 public void setERC(String ERC){
 this.ERC=ERC;
 }
 public String getERC(){
 return ERC;
 }
 public void setPVP(String PVP){
 this.PVP=PVP;
 }
 public String getPVP(){
 return PVP;
 }
 
    
}
