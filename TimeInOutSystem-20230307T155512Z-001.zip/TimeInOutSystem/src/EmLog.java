import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;
import java.sql.*;
import net.proteanit.sql.DbUtils;
public class EmLog extends javax.swing.JFrame {
    public EmLog() {
        initComponents();
        showEmLog();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        displaylog = new javax.swing.JTable();
        jButton4 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("OK");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jButton1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton1KeyPressed(evt);
            }
        });

        jLabel1.setText("Employee Time In/Time Out Log:");

        displaylog.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Employee's Reference Code", "Time In", "Time Out", "Date"
            }
        ));
        displaylog.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                displaylogMouseClicked(evt);
            }
        });
        displaylog.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                displaylogKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                displaylogKeyTyped(evt);
            }
        });
        jScrollPane2.setViewportView(displaylog);

        jButton4.setText("Refresh");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jButton4.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButton4KeyPressed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jButton4)))
                        .addGap(0, 498, Short.MAX_VALUE))
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton4))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       dispose();
       TimeInOut1 tio = new TimeInOut1();
       tio.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void displaylogMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_displaylogMouseClicked
      boolean b = displaylog.isEditing();
    if(b==false){
    JOptionPane.showMessageDialog(null, "Fields in this table cannot be edited"
            + "\nand are for display/reference purposes only.");
    }
    }//GEN-LAST:event_displaylogMouseClicked

    private void jButton1KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton1KeyPressed

    }//GEN-LAST:event_jButton1KeyPressed

    private void displaylogKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_displaylogKeyTyped
       
    }//GEN-LAST:event_displaylogKeyTyped

    private void displaylogKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_displaylogKeyPressed
  int k=evt.getKeyCode();
        if(k==KeyEvent.VK_UP||k==KeyEvent.VK_DOWN||k==KeyEvent.VK_LEFT||k==KeyEvent.VK_RIGHT){
        displaylog.grabFocus();
        }
        else if(k!=KeyEvent.VK_UP||k!=KeyEvent.VK_DOWN||k!=KeyEvent.VK_LEFT||k!=KeyEvent.VK_RIGHT){
        boolean b = displaylog.isEditing();
        if(b==false){
    JOptionPane.showMessageDialog(null, "Fields in this table cannot be edited"
            + "\nand are for display/reference purposes only.");
    } 
        } 
    }//GEN-LAST:event_displaylogKeyPressed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
  try{
Connection con = con=DriverManager.getConnection("jdbc:mysql://localhost:3306/system","root","");
String sql = "Select ERC,Time_In,Time_Out,Date from timeinout";
PreparedStatement pst = con.prepareStatement(sql);
ResultSet rs = pst.executeQuery();
displaylog.setModel(DbUtils.resultSetToTableModel(rs));
}
catch(Exception e){
JOptionPane.showMessageDialog(null,"An error has been detected leading to the said action unable to be performed and"
                    + "\nmay have been caused by the following reason:"
                    + "\n1. A stable connection between the program and the database could not be established. Please"
                    + "\nopen your XAMPP Control Panel and start the 'Apache' and 'MySQL' services."
                    + "\nFor more information regarding on the problem, please refer to the statement below:\n"
                    +e,"Error!",JOptionPane.ERROR_MESSAGE);
}
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton4KeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButton4KeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton4KeyPressed
public void showEmLog(){
try{
Connection con = con=DriverManager.getConnection("jdbc:mysql://localhost:3306/system","root","");
String sql = "Select ERC,Time_In,Time_Out,Date from timeinout";
PreparedStatement pst = con.prepareStatement(sql);
ResultSet rs = pst.executeQuery();
displaylog.setModel(DbUtils.resultSetToTableModel(rs));
}
catch(Exception e){
JOptionPane.showMessageDialog(null,"An error has been detected that led to the result that the table "
                    + "\ncannot display the contents of the employee log."
                    + "\n1. A stable connection between the program and the database could not be established."
                    + "\nPlease open your XAMPP Control Panel and start the 'Apache' and 'MySQL' services."
                    + "\nAs a result from the problem, only an empty table will be shown to the user"
                    + "\nand a few buttons. Be warned that the 'Refresh' button will not function because"
                    + "\nof the existing problem in the program."
                    + "\nFor more information regarding on the problem, please refer to the statement below:"
                    + "\n"+e,"Error!",JOptionPane.ERROR_MESSAGE);
}
}
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EmLog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EmLog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EmLog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EmLog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EmLog().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable displaylog;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    // End of variables declaration//GEN-END:variables
}
